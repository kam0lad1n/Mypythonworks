# print("Your class persent data")
# x = int(input("Jami oquvchilar:"))
# b = int(input("Necha o'g'il bor:"))
# c = int(input("Necha qiz bor:"))
# all = b + c
# boys = (b/all)*100
# girls= (c/all)*100
# print("Sinfingizdagi o'g'il bolalar",int(boys),"%")
# print("Sinfingizdagi qiz bolalar",int(girls),"%")
#
#


x = int(input("x:"))

onb = x - 10

x1 = int(x*46/100)
x2 = int(onb*62/100)
j = x1 - x2
print(x1, x2)
print(j)
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
# #
# # f1 = "x² + 4x +56"
# # f2 = "x³ + 3x² + 32x + 8"
# # f3 = "(a + b)²"
# # f4 = "(a+b)³"
# # f5 = "(x +y²)² × 3x +4y"
# # print(">Formulas<")
# # print("1." + f1)
# # print("2." + f2)
# # print("3." + f3)
# # print("4." + f4)
# # print("5." + f5)
# #
# # chose = int(input("Qaysi formuladan foydalanmoqchisiz:"))
# #
# # if chose == 1 :
# #     print(f1)
# #     x = int(input("X ga qiymat bering:"))
# #     print(x**2+4*x+56)
# # elif chose == 2 :
# #     print(f2)
# #     x = int(input("X ga qiymat bering:"))
# #     print(x**3+3*x**2+32*x+8)
# # elif chose == 3 :
# #     print(f3)
# #     a = int(input("A ga qiymat bering:"))
# #     b = int(input("B ga qiymat bering:"))
# #     print((a+b)**2)
# # elif chose == 4 :
# #     print(f4)
# #     a = int(input("A ga qiymat bering:"))
# #     b = int(input("B ga qiymat bering:"))
# #     print((a + b)**3)
# # elif chose == 5 :
# #  print(f5)
# #  x = int(input("X ga qiymat bering:"))
# #  y = int(input("Y ga qiymat bering:"))
# #  print(((x+y*y)**2) * 3*x+4*y)
# # else:
# #
# #     print("Formula topilmadi!")