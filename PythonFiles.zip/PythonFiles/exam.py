import math


#1111111111111111111111111111111111111111111111111111111111

# a = int(input("Natural son: "))
#
# if a % 2 == 0:
#     if a % 4 ==0:
#        print("Bu son juft va 4ga bo'linadi.")
#     else:
#          print("Bu son 4ga bolinmaydi.")
# else:
#     print("Bu son toq")




#22222222222222222222222222222222222222222222222222222222222222
# a = int(input("Natural son: "))
#
# if a % 2 == 1:
#     if a % 5 ==0:
#        print("Bu son toq va 5ga bo'linadi.")
#     else:
#        print("Bu son 5ga bo'linmaydi.")
# else:
#     print("Bu son juft ")

#3333333333333333333333333333333333333333333333333333333333333333
# a = int(input("Natural son: "))
#
# if a % 2 == 1:
#     if a % 7 ==0:
#        print("Bu son toq va 7ga bo'linadi.")
#     else:
#        print("Bu son 7ga bo'linmaydi.")
# else:
#     print("Bu son juft")

#444444444444444444444444444444444444444444444444444444444444444

# a = int(input("Natural son: "))
#
# if a % 2 == 0:
#     if a % 10 ==0:
#        print("Bu son juft va 10ga bo'linadi.")
#     else:
#         print("Bu son 10ga bo'linmaydi.")
# else:
#     print("Bu son toq.")

#5555555555555555555555555555555555555555555555555555555555555555
#
# a = int(input("Quti eni: "))
# b = int(input("Quti bo'yi: "))
# m = int(input("Eshik m: "))
# n = int(input("Eshik n: "))
#
# if a <= m and b <= n:
#     print("Quti eshikdan o'ta oladi.")
# else:
#     print("Quti teshikdan o'ta olmaydi")

#66666666666666666666666666666666666666666666666666666666666666666666

# a = int(input("Son : "))
# if a>0 :
#     print("Bu son musbat.")
# elif a==0:
#     print("Bu son 0")
# else:
#     print("Bu son manfiy.")

#77777777777777777777777777777777777777777777777777777777777777777777
# a = int(input("Brusni eni : "))
# d = int(input("G'o'lani eni : "))
# if d >= a:
#     print("G'o'la brussni kesa oladi.")
# else:
#     print("G'o'la brussni kesa olmaydi.")
#8888888888888888888888888888888888888888888888888888888888888888888888888

# s = int(input("Zal tomoni: "))
# r = int(input("Sahna radiusi: "))
#
# if 4*2<10:
#     print("Sahna sig'adi va ",((10)-(4*2))/4, "metr joy qoladi."  )
# elif 4*2==10:
#     print( "Sahna sig'adi lekin joy qolmaydi")
# else:
#     print("Sahna Zalga sig'maydi")



# if 4*2<10:
#     print("Sahna sig'adi va ",((10)-(4*2))/4, "sm joy qoladi."  )
# elif 4*2==10:
#     print( "Sahna sig'adi lekin joy qolmaydi")
# else:
#     print("Sahna Zalga sig'maydi")
#9999999999999999999999999999999999999999999999999999999999999999999999999999999
# print("Eslatib o'tamiz vagonda faqat 10ta o'rin mavjud.")
# n = int(input("Vagon raqami: "))
# if n == 1:
#     print("Sizni joyingiz vagonning 1-bo'lmasini pastgi qismda ")
# elif n == 2:
#     print("Sizni joyingiz vagonning 1-bo'lmasini yuqori qismda ")
# elif n == 3:
#     print("Sizni joyingiz vagonning 2-bo'lmasini pastgi qismda ")
# elif n == 4:
#     print("Sizni joyingiz vagonning 2-bo'lmasini yuqori qismda ")
# elif n == 5:
#     print("Sizni joyingiz vagonning 3-bo'lmasini pastgi qismda ")
# elif n == 6:
#     print("Sizni joyingiz vagonning 3-bo'lmasini yuqori qismda ")
# elif n == 7:
#     print("Sizni joyingiz vagonning 4-bo'lmasini pastgi qismda ")
# elif n == 8:
#     print("Sizni joyingiz vagonning 4-bo'lmasini yuqori qismda ")
# elif n == 9:
#     print("Sizni joyingiz vagonning 1-yon bo'lmasini pastgi qismda ")
# elif n == 10:
#     print("Sizni joyingiz vagonning 1-yon bo'lmasini yuqori qismda ")
# else:
#     print("Joy raqami bu vagonga tegishli emas.")
#1010101010101010101011101010101010101

# pul = int(input("Qancha pulingiz bor: "))
# print("500 so'mlik = 1")
# print("100 so'mlik = 2")
# print("10 so'mlik = 3")
# print("2 so'mlik = 4")
# valyuta = int(input("Qanday tangaga almashmoqchisiz:"))
#
# if valyuta == 1:
#     print(pul // 500, "ta 500 so'mlik tanga olasiz")
# elif valyuta == 2:
#     print(pul//100,"ta 100 so'mlik tanga olasiz")
# elif valyuta == 3:
#     print(pul//10,"ta 10 so'mlik tanga olasiz")
# elif valyuta == 4:
#     print(pul//2, "ta 2 so'mlik tanga olasiz")
# else:
#     print("Uzur bunday pul birligi yoq.")
#
# #111111111111111111111111111111111111111111111111111111111111111111111111111
#
# a = int(input("Kub tomoni : "))
# b = int(input("Konusning boyi:"))
# c = int(input("Konusning radiusi:"))
# kub_hajm = a**3
# konus_hajm = 3.14*(c*2)*b

# m = int(input("Suv hajmi : "))
# kub_hajm = 125
# konus_hajm = 150
# if  m <= kub_hajm and m <= konus_hajm:
#     print(" Suv kubga va konusga mos keladi.")
# elif m <= kub_hajm and m > konus_hajm:
#     print("Suv kubga mos keladi lekin konusga mos kelmaydi.")
# elif m > kub_hajm and m <= konus_hajm:
#     print("Suv konusga mos keladi lekin kubga mos kelmaydi.")
# else:
#     print("Suv ikkisiga ham mos kelmaydi.")


# kubnihajmi = 100
# konusnihajmi = 20
# suvnihajmi = 15
#
# if kubnihajmi >= suvnihajmi:
#     print("Suv kubga togri keladi")
# elif konusnihajmi >= suvnihajmi:
#     print("Suv konusga togri keladi")



#22222222222222222222222222222222222222222222222222222222222222222222222222222222
# a = int(input("Kub tomoni : "))
# b = int(input("Konusning boyi:"))
# c = int(input("Konusning radiusi:"))
# m = int(input("Suv hajmi : "))
# kub_hajm = a**3
# konus_hajm = (1/3)*3.14*(c*2)*b
#
# if  m <= kub_hajm and m <= konus_hajm:
#     print("Kubga va Konusga suv to'ldirish mumkin.")
# elif m <= kub_hajm and m > konus_hajm:
#     print("Kubga suv to'ldirish mumkin lekin Konusga suv to'lmaydi.")
# elif m > kub_hajm and m <= konus_hajm:
#     print("Konusga suv to'ldirish mumkin lekin Kubga suv to'lmaydi.")
# else:
#     print("Suv ikkisida ham to'lmaydi")

#3333333333333333333333333333333333333333333333333333333333333333333333333333
# a = int(input("A tomoni: "))
# b = int(input("B tomoni: "))
# c = int(input("C tomoni: "))
#
# if a >0 and b >0 and c > 0:
#     print("Bular uchburchak bola oladi.")
# else:
#     print("Bular uchburchak bola olmaydi.")
#
# if c == a+b:
#     print("Bu to'g'ri burchakli uchburchak.")
# else:
#     print("Bu to'g'ri burchakli uchburchak emas.")
#444444444444444444444444444444444444444444444444444444444444444444444444444444444
#14-misol
#  x soni berilgan bu raqam [a;b] oraliqqa tegishli yoki yo'qligini aniqlash kerak

# x = int(input("Biror raqam kiriting: "))
# a = int(input("a nuqtani kiriting: "))
# b = int(input("b nuqtani kiriting: "))
#
# if x >= a and x <= b:
#     print("Shu oraliqqa tegishli son !")
# else:
#     print("Bu oraliqqa tegishli son emas !")

#5555555555555555555555555555555555555555555555555555555555555555555
# x = int(input("X soni: "))
# y = int(input("Y soni: "))
# z = 1/(x*y)
# print(z)
#6666666666666666666666666666666666666666666666666666666666666666



#8888888888888888888888888888888888888888888888888888888888888888888888

# yil = int(input("Yil: "))
# asr = yil//100+1
# if yil%4==0:
#     print("Bu yil pog'ona yili va", asr, "asr")
# else:
#     print("Bu yil pog'ona yili emas va", asr, "asr")


#################################################################################################
# import math
# s = 144
# a = math.sqrt(s)
# k = 2
# r =6
#
# if a>=r*2+k:
#     print("Boladi")
# else:
#     print("Bolmaydi")





