# 1-masala
# ijobiyson = 0
# sonlar = int(input("Ijobiy son kiriting:"))
#
# while ijobiyson != sonlar:
#     print("Bu ijobiy son emas")
#     sonlar = int(input("Ijobiy son kiriting:"))
# print("Bu ijobiy son.")
# 2-masala
# i = 2
# while i <= 100:
#     print(i)
#     i += 2
# 3-masala
# import random
# maxfiyson = random.randint(1,11)
# while True:
#     son = int(input("Maxfiy sonni toping:"))
#     if maxfiyson != son:
#         print("Yo'q siz topolmadingiz!")
#     else:
#         print("Qoyil siz topdingiz!")
#         break
# 4-masala
#
# while True:
#     matn = str(input("Matn kiriting:"))
#     if matn != "stop":
#         print(matn)
#     else:
#         break
# 5-masala
# while True:
#     son1 = int(input("Birinchi sonni kiriting:"))
#     son2 = int(input("ikkinchi sonni kiriting:"))
#     son3 = int(input("Uchinchi sonni kiriting:"))
#     yigindi = son1 + son2 + son3
#     if yigindi != 0:
#         print("Yig'indi:",yigindi)
#     else:
#         break
#     ques = int(input("Davom etamizmi?:"))
#     if ques == 1:
#         continue
#     else:
#         break
# 6-masala
# while True  :
#     son = int(input("Son kiriting:"))
#     yigindi = sum(range(1, son))
#     print(yigindi)
# 7-masala
# i = 1
# while i < 20:
#     print(i)
#     i += 2
# 8-masala
# parol = "parol"
# inparol = str(input("Parolni kiriting:"))
# while parol != inparol:
#     print("Bu parol mos emas!")
#     inparol = str(input("Parolni kiriting:"))
# print("Parol to\'g\'ri!")
# 9-masala
# n = int(input("Son kiriting:"))
# i =1
# while i <= n:
#     print(i)
#     i +=1
# 10-masala
# while True:
#     son1 = int(input("Birinchi sonni kiriting:"))
#     son2 = int(input("ikkinchi sonni kiriting:"))
#     son3 = int(input("Uchinchi sonni kiriting:"))
#     yigindi = son1 + son2 + son3
#     if son1 < 0:
#         print("Kechirasiz bu son manfiy ", son1)
#         break
#     elif son2 < 0:
#         print("Kechirasiz bu son manfiy ", son2)
#         break
#     elif son3 < 0:
#         print("Kechirasiz bu son manfiy ", son3)
#         break
#     elif yigindi != 0:
#         print("Yig'indi:",yigindi)
#     else:
#         break
#     ques = int(input("Davom etamizmi?:"))
#     if ques == 1:
#         continue
#     else:
#         break
# 11-masala
# while True:
#     son1 = int(input("Birinchi sonni kiriting:"))
#     son2 = int(input("ikkinchi sonni kiriting:"))
#     son3 = int(input("Uchinchi sonni kiriting:"))
#     yigindi = son1 + son2 + son3
#     if son1 > 0:
#         print("Kechirasiz bu son musbat", son1)
#         break
#     elif son2 > 0:
#         print("Kechirasiz bu son musbat", son2)
#         break
#     elif son3 > 0:
#         print("Kechirasiz bu son musbat", son3)
#         break
#     print(son1, son2, son3)
#     ques = int(input("Davom etamizmi?:"))
#     if ques == 1:
#         continue
#     else:
#         break
# 12-masala
# while True:
#     ism = str(input("Matn kiriting:"))
#     if ism != "stop":
#         print(ism)
#     else:
#         print("Stopped!")
#         break
# 13-masala
# i = 0
# while i < 100:
#     i += 1
#     print(i**2)
# 14-masala
# import math
# while True:
#     son = int(input("Biror son yozing:"))
#     if son > 0:
#         print(son,"ning faktoriali",math.factorial(son))
#     else:
#         print("Bu manfiy son")
#         break
# 15-masala
# while True:
#     n = int(input("Biror son yozing:"))
#     son1 = int(0)
#     son2 = 1
#     knraqam = son1
#     count = 1
#     while count <= n:
#         print(knraqam)
#         count += 1
#         son1, son2 = son2, knraqam
#         knraqam = son1 + son2
#     print()
#
#
#
#
