while True:
    son = int(input("Davom etamizmi?:"))
    if son != 0:
        print(son)
    else:
        break