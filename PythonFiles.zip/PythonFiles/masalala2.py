#111111111111111111111111111111111111111111111111111111111111111111111
# 1-masala
# kavadrat tenglamani yechish:   ax^2 + bx + c      D = b^2 - 4ac
import math

a = float(input("a ning qiymati: "))
b = float(input("b ning qiymati: " ))
c = float(input("c ning qiymati: " ))

diskirminant = b**2 - 4*a*c

if diskirminant > 0:
    x1 = (-b + math.sqrt(diskirminant))/(2*a)
    x2 = (-b - math.sqrt(diskirminant))/(2*a)
    print("tenglamaning 2 ta yechimi bor:", x1, x2)
elif diskirminant == 0:
    x = -b/(2*a)
    print("tenglamaning ildizi 1 dona va u", x)
else:
    print("tenglama yechimga ega emas")

#222222222222222222222222222222222222222222222222222222222222222222222
a = int(input("A tomoni: "))
b = int(input("B tomoni: "))
c = int(input("C tomoni: "))
if a >0 and b >0 and c > 0:
    print("Bular uchburchak bola oladi.")
else:
    print("Bular uchburchak bola olmaydi.")

#333333333333333333333333333333333333333333333333333333333333333333333
v = int(input("Soat:"))
m = int(input("Minut:"))
if v > 0 and v < 23 and m > 0 and m < 59:
    print("Vaqt to'g'ri")
else:
    print("Vaqt noto'g'ri!")
#44444444444444444444444444444444444444444444444444444444444444444444444444
d = int(input("Oy: "))
if d == 1:
     print("Hozir yilning Yanvar oyi va Qish fasli")
elif d == 2:
    print("Hozir yilning Fevral oyi va Qish fasli")
elif d == 3:
    print("Hozir yilning Mart oyi va Bahor fasli")
elif d == 4:
    print("Hozir yilning Aprel oyi va Bahor fasli")
elif d == 5:
    print("Hozir yilning May oyi va Bahor fasli")
elif d == 6:
    print("Hozir yilning Iyun oyi va Yoz fasli")
elif d == 7:
    print("Hozir yilning Iyul oyi va Yoz fasli")
elif d == 8:
    print("Hozir yilning Avgust oyi va Yoz fasli")
elif d == 9:
    print("Hozir yilning Sentabr oyi va Kuz fasli")
elif d == 10:
    print("Hozir yilning Oktabr oyi va Kuz fasli")
elif d == 11:
    print("Hozir yilning Noyabr oyi va Kuz fasli")
elif d == 12:
    print("Hozir yilning Dekabr oyi va Kuz fasli")
else:
    print("Bunday oy raqami mavjud emas!")

#555555555555555555555555555555555555555555555555555555555555555555555
a = int(input("Birinchi son: "))
b = int(input("Ikkinchi son: "))
c = int(input("Uchinchi son: "))


if b*2 == a+b:
    print("Arifmetik progressiyaga to'g'ri keladi.")
else:
    print("false")
if b**2 == a*b:
    print("Geometrik progressiyaga to'g'ri keladi.")
else:
    print("false")
#666666666666666666666666666666666666666666666666666666666666666666666666
raqam_kodi = int(input("Kodni kiriting!:"))

if raqam_kodi == +998:
    print("Kod raqami Ozbekistonga tegishli:")
elif raqam_kodi == +1:
    print("Kod raqami Amerikaga tegishli:")
elif raqam_kodi == +7:
    print("Kod raqami Qozoqiston tegishli:")
elif raqam_kodi == +54:
    print("Kod raqami Argentinaga tegishli:")
elif raqam_kodi == +86:
    print("Kod raqami Xitoyga tegishli:")
elif raqam_kodi == +33:
    print("Kod raqami Fransiyaga tegishli:")
elif raqam_kodi == +49:
    print("Kod raqami Germaniyaga tegishli:")
elif raqam_kodi == +91:
    print("Kod raqami Hindistonga tegishli:")
else:
    print("Bilmayman1")
#777777777777777777777777777777777777777777777777777777777777777777777777
yil = int(input("Yillik daromadiz!:"))
a = yil /100
b = a*12
print(b, "-bu sizning yillik solog'ingiz")
print(b/100*0.01, "Pensionniy soliq")

#8888888888888888888888888888888888888888888888888888888888888888888888888888888888

a = int(input("A tomoni: "))
b = int(input("B tomoni: "))
c = int(input("C tomoni: "))


if c == a+b:
    print("Bu to'g'ri burchakli uchburchak.")
else:
    print("Bu to'g'ri burchakli uchburchak emas.")

if a==b :
    print("Bu teng yonli uchburchak")
else:
    print("Bu teng yonli  uchburchak emas.")

if a==b and b==c:
    print("Bu teng tomonli uchburchak")
else:
    print("Bu teng tomonli uchburchak emas.")

#999999999999999999999999999999999999999999999999999999999999999999999999999999999

ip = input("Enter IP Address: ")
if ip == "192.168.1.1" or ip == "192.168.1.100" or ip == "192.168.100.1" :
    print("Bu localhost IP address")
else:
    print("Bu localhost IP address emas")

#1010101010101010101010101011101001001001010101010101001001001001001001001001000101010010

ball1 = int(input("1-savolda necha ball oldingiz: "))
ball2 = int(input("2-savolda necha ball oldingiz: "))
ball3 = int(input("3-savolda necha ball oldingiz: "))
ball4 = int(input("4-savolda necha ball oldingiz: "))
ball5 = int(input("5-savolda necha ball oldingiz: "))

ortacha = (ball1 + ball2 + ball3 + ball4 + ball5)/5
print("Sizning o'rtacha balingiz.",ortacha)



student_ball = int(input("Imtihonda necha ball oldingiz: "))

if student_ball == 0:
    print("0 baho, Kalla tashabsanqu jo'ra )")
elif student_ball>0 and student_ball<60:
    print("2 baho. Imtihonnan yiqilding kisa go'tarami indi )")
elif student_ball>=60 and student_ball<70:
    print("3 baho. Jolliroq o'qi indi")
elif student_ball>=70 and student_ball<90:
    print("4 baho. Hozircha yaxshi.")
elif student_ball>=90 and student_ball<=100:
    print("5 baho. A'lo ")
else:
    print("Manimcha siz xato ball kiritdingiz")

#11111111111111111111111111111111111111111111111111111111111111111111111111111111111

a = int(input("Enter a Eni: "))
b = int(input("Enter a Boyi: "))

if a==b:
    print("Bu kvadrat")
else:
    print("Bu kvadrat emas!")

#222222222222222222222222222222222222222222222222222222222222222222222222222222222

a = int(input("Enter a One: "))
b = int(input("Enter a Two: "))

if a + b == 10 or a-b == 10 or b-a == 10:
    print("Win")
else:
    print("Lose")

#3333333333333333333333333333333333333333333333333333333333333333333333333333333333333

print("Kredit olish.")
print("Ha = 1")
print("Yo'q = 0")
kr = input("Avval kredit olganmisiz?")
if kr == "1":
    print("Siz kredit ololmaysiz!")
elif kr == "0" :
    print("Siz kredit ola olasiz.")
else:
    print("Notogri qiymat, kredit kerak emasmi?")












