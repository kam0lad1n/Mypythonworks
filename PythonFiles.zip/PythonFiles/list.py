#1masala
# sonlar = []
# while True:
#     add = int(input("Son kiriting:"))
#     if add != 0:
#         sonlar.append(add)
#     else:
#         print(sonlar)
#2masala
# royxat =[7,5,8,1,2,4,9]
# royxat.sort()
# print(royxat[6])
# print(royxat[0])
#3masala
# royxat =[7,5,8,1,2,4,9]
# print(sum(royxat))
#4masala
# royxat =[7,5,8,1,2,4,9]
# print(sum(royxat)//len(royxat))
#6masala
# royxat =[7,5,8,1,2,4,9]
# royxat.sort()
# print(royxat)
#7masala
# royxat =[7,5,8,1,2,4,9]
# print(royxat)
# rm = int(input("Qaysi indeksni o'chirmoqchisiz?"))
# royxat.pop(rm)
# print(royxat)
#8masala
# royxat =[7,5,8,1,2,4,9]
# indx = int(input("Qaysi indeksdaki kerak?"))
# print(royxat[indx])
#9masala
# words = ["salom", "good", "bye", "welcome"]
# words.sort()
# print(words)
#10masala
# words = ["salom", "good", "bye", "welcome"]
# indx = str(input("Ro'yxatdaki so'zni kiriting:"))
# if words.count(indx) != 0:
#     print(indx, "-ro'yxatda bor!")
# else:
#     print(indx, "ro'yxatda yo'q!")
#11masala
# bir_list=["bir","ikki","uch"]
# iki_list=["to'rt","besh","olti"]
# bir_list.extend(iki_list)
# print(bir_list)
#12masala
# list=["bir","ikki","uch"]
# list.reverse()
# print(list)
#13masala
# listin=["bir","ikki","uch"]
# print(listin)
# indeks = int(input("Qaysi indeksdagi qiymatni ikkilantirmoqchisiz?"))
# add= listin[indeks]
# listin.append(add)
# print(listin)
#14masala
# royxat=[-7,5,-8,1,-2,4,9]
# for son in royxat:
#     if son > 0:
#         print(son)
#15masala
# bir_list=["besh","ikki","olti"]
# iki_list=["ikki","besh","uch"]
# for item in bir_list:
#     if item in iki_list:
#         new_list = [item]
#         print(new_list)







