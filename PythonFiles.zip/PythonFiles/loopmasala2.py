#1-masala
# while True:
#     ism = str(input("Ismingizni kiriting:"))
#     if ism != "exit":
#         print("Salom",ism)
#     else:
#         break
#
#2-masala
# i = 1
# while i <= 100:
#     if i%3==0 :
#         print(i)
#     i += 1
#3-masala
# while True:
#     yosh = int(input("Yoshingizni kiriting:"))
#     if yosh >= 18:
#         print("Voyaga yetgansiz!")
#     elif yosh <= 18 and yosh > 0:
#         print("Siz hali kichkinasiz")
#     else:
#         print("Siz hali tugilmagansiz")
#         break
#4-masala
# while True:
#     son = int(input("Son kiriting:"))
#     if son != 0:
#         kv = son**2
#         print(kv)
#     else:
#         break
#5-masala
# while True:
#     son1 = int(input("Birinchi sonni kiriting:"))
#     son2 = int(input("ikkinchi sonni kiriting:"))
#     son3 = int(input("Uchinchi sonni kiriting:"))
#     yigindi = son1 + son2 + son3
#     if yigindi != 0 and son1%2==1 and son2%2==1 and son3%2==1:
#         print("Yig'indi:",yigindi)
#     else:
#         print("Sonlar orasida jufti bor")
#         break
#     ques = int(input("Davom etamizmi?:"))
#     if ques == 1:
#         continue
#     else:
#         break
#6-masala
# while True:
#     matn = str(input("Matn kiriting:"))
#     unlilar =["a","e","o","i","u"]
#     if matn != "stop" and matn == unlilar:
#         print()
#     else:
#         break
from PythonFiles.masalala2 import ortacha

#
# def count_vowels(text):
#     vowels = "aeıioöuüAEIİOÖUÜ"
#     count = 0
#     index = 0
#
#     while index < len(text):
#         if text[index] in vowels:
#             count += 1
#         else:
#             pass  # Bu kısmı geçiyoruz, ek işlem yok
#         index += 1
#
#     return count
#
# # Kullanıcıdan metin alıp ünlü sayısını bulma
# text = input("Bir metin girin: ")
# vowel_count = count_vowels(text)
# print("Metindeki ünlü harf sayısı:", vowel_count)

#7-masala
#
# while True:
#     son1 = int(input("Birinchi sonni kiriting:"))
#     son2 = int(input("ikkinchi sonni kiriting:"))
#     kopaytma = son1 * son2
#     if kopaytma != 0 and son1!=0 and son2==0 or son1==0 and son2!=0:
#         print("Ko'paytma:",kopaytma)
#     else:
#         break
#     ques = int(input("Davom etamizmi?:"))
#     if ques == 1:
#         continue
#     else:
#         break
#8-masala

# while True:
#         son = int(input("Biror son kiriting:"))
#         if son !=0 and son%10==0:
#             print(son//10)
#             son += 1
#         else:
#             break
#9-masala
# while True:
#     son = int(input("Qaysidir sonni kiriting:"))
#     if son**2 <=1000:
#         print(son**2)
#         son =+1
#     else:
#         print("Bu sonning kvadrati 1000dan katta!")
#
#10-masala
# while True:
#     son1 = int(input("Birinchi sonni kiriting:"))
#     son2 = int(input("ikkinchi sonni kiriting:"))
#     son3 = int(input("Uchinchi sonni kiriting:"))
#     if son1>son2 and son1>son3:
#         print(son1)
#     elif son2>son1 and son2>son3:
#         print(son2)
#     else:
#         print(son3)
#     ques = int(input("Davom etamizmi?:"))
#     if ques != 0:
#         continue
#     else:
#         break
#11-masala

# while True:
#     son = int(input("Davom etamizmi?:"))
#     if son != 0:
#         print(son)
#     else:
#         break


















































