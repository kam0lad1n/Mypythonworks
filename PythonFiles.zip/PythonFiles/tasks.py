x = int(input("X ga qiymat bering: "))

#masala1
ogil = int(x*40/100)
qiz = int(x-ogil)
print(ogil)
print(qiz)
#masala2
onincia = x
yy = onincia*20/100
onincib = onincia+yy
print(onincib)
#masala3
ogilbolalar = x*48/100
qizbolalar = x - ogilbolalar
javob = qizbolalar-ogilbolalar
print(javob)
#masala4
y = int(input("Y ga qiymat bering: "))
j = (x+5)-(y+5)
print(j)
#masala5
birsinf= x*15/100
jav = x + birsinf


