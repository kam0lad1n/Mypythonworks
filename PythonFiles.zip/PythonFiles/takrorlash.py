#1masala
# son = int(input("Enter a number: "))
# if son > 0:
#     print("Bu son musbat!")
# elif son == 0:
#     print("Bu son 0ga teng!")
# else:
#     print("Bun son manfiy!")
#2masala
# matn = "lorem binnasa binnasa lorem quri htmlda ishlidi akan indi bildim"
# unli = "aeiou"
# undosh = "qwrtypsdfghjklzxcvbnm"
# unlila_soni = 0
# undoshla_soni = 0
# for i in matn:
#         if i in unli:
#             unlila_soni+=1
# print("Matnda",unlila_soni,"ta unli bor!")
# for i in matn:
#     if i in undosh:
#         undoshla_soni+=1
# print("Matnda",undoshla_soni,"ta undosh bor!")
#3masala
# sum =0
# for i in range(1,21):
#     sum +=i
#     print(sum)
#4masala
# x = "malayalam"
# w = ""
# for i in x:
#     w = i + w
#
# if x == w:
#     print("Yes")
# else:
#     print("No")
#5masala
# a_son = int(input("Enter a son number: "))
# b_son = int(input("Enter a son number: "))
# c_son = int(input("Enter a son number: "))
# d_son = int(input("Enter a son number: "))
# e_son = int(input("Enter a son number: "))
#
# if a_son%2 ==0:
#     print(a_son)
# elif b_son%2 ==0:
#     print(b_son)
# elif c_son%2 ==0:
#     print(c_son)
# elif d_son%2 ==0:
#     print(d_son)
# elif e_son%2 ==0:
#     print(e_son)
# else:
#     print("Juft son yo'q")
#     print(a_son,b_son,c_son,d_son,e_son)
#6masala
# soz = str(input("Enter a words: "))
# print(soz[::-1])
#7masala
# matn = "lorem binnasa binnasa lorem quri htmlda ishlidi akan indi bildim"
# print(matn.count(" "))
#8masala
# num = int(input("Enter a number: "))
# bir = 1
# faktorial = 1
# while bir <= num:
#   faktorial *= bir
#   bir += 1
# print(faktorial)
#9masala
a_son = int(input("Enter a son number: "))
b_son = int(input("Enter a son number: "))
c_son = int(input("Enter a son number: "))
d_son = int(input("Enter a son number: "))
e_son = int(input("Enter a son number: "))


