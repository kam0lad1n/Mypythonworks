matn = str(input("Enter a text: "))
#1masala
print(matn.strip())
#2masala
print(matn.lower())
#3masala
print(matn.find("Python"))
#4masala
print(len(matn))
#5masala
print(matn.capitalize())
#6masala
print(matn.title())
#7masala
print(matn.rjust(10))
#8masala
print(matn.replace("a","o"))
#9masala
print(matn.startswith("Hello"))
#10masala
print(matn.endswith("!"))
#11masala
print(matn.isdigit())
#12masala
print(matn.split(""))
#13masala
print(matn.swapcase())
#14masala
print(matn.isalpha())
#15masala
print(matn.zfill(10))



