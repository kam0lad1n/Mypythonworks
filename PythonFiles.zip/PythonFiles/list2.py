#1masala
# royxat=[-7,5,-8,1,-2,4,9]
# print("Musbat sonlar")
# for son in royxat:
#     if son > 0:
#         print(son)
# print("Manfiy sonlar")
# for son in royxat:
#     if son < 0:
#         print(son)
#2masala
# royxat=[-7,5,-8,1,-2,4,9]
# print(royxat)
# indx = int(input("Enter a number: "))
# print(royxat.index(indx))
#3masala
# royxat = [2, 5, -8, 9, 2, 5, 9]
# if royxat.count(0) >= 2:
#     royxat.remove(0)
#     print(royxat)
# elif royxat.count(1) >= 2:
#     royxat.remove(1)
#     print(royxat)
# elif royxat.count(2) >= 2:
#     royxat.remove(2)
#     print(royxat)
# elif royxat.count(3) >= 2:
#     royxat.remove(3)
#     print(royxat)
# elif royxat.count(4) >= 2:
#     royxat.remove(4)
#     print(royxat)
# elif royxat.count(5) >= 2:
#     royxat.remove(5)
#     print(royxat)
# elif royxat.count(6) >= 2:
#     royxat.remove(6)
#     print(royxat)
# else:
#     print(royxat)
#4masala
royhat = [5, 6, 10, 4, 7, 1, 19]

print("The original list is : " + str(royhat))

res = []
for idx, ele in enumerate(royhat):
    if ele % 2 != 0:
        res.append(idx)
print("Indices list Odd elements is : " + str(res))
