# x = int(input("Enter a number to X: "))
# #Birinchi masala
# if x >= 0:
#     print("Bu son musbat")
# else:
#     print("Bu son manfiy")


    #Ikkinchimasala
# x = int(input("Enter a number: "))
# if x % 2 ==0:
#     print("Bu son Juft")
# else:
#     print("Bu son Toq")

#ucinci masala
# x = int(input("Enter a number to X: "))
# y = int(input("Enter a number to Y: "))
#
#
# if x > y:
#     print("X - Y dan katta")
# elif x == y:
#    print("Bular teng")
# else:
#     print("X - Y dan kichik")

# #masala4
# v = int(input("Soat necha bo'ldi: "))
# if v >= 6 and v < 12 :
#      print("Hayrli tong")
# elif v >= 12 and v < 18:
#     print("Hayrli kun")
# elif v >= 18 and v < 22:
#     print("Hayrli kech")
# elif v >= 22 and v < 1:
#     print("Osuda tun")
# else:
#     print("salom")

#masala5
# d = int(input("Hozir yilning qaysi oyi: "))
# if d == 1:
#      print("Hozir yilning Yanvar oyi va Qish fasli")
# elif d == 2:
#     print("Hozir yilning Fevral oyi va Qish fasli")
# elif d == 3:
#     print("Hozir yilning Mart oyi va Bahor fasli")
# elif d == 4:
#     print("Hozir yilning Aprel oyi va Bahor fasli")
# elif d == 5:
#     print("Hozir yilning May oyi va Bahor fasli")
# elif d == 6:
#     print("Hozir yilning Iyun oyi va Yoz fasli")
# elif d == 7:
#     print("Hozir yilning Iyul oyi va Yoz fasli")
# elif d == 8:
#     print("Hozir yilning Avgust oyi va Yoz fasli")
# elif d == 9:
#     print("Hozir yilning Sentabr oyi va Kuz fasli")
# elif d == 10:
#     print("Hozir yilning Oktabr oyi va Kuz fasli")
# elif d == 11:
#     print("Hozir yilning Noyabr oyi va Kuz fasli")
# elif d == 12:
#     print("Hozir yilning Dekabr oyi va Kuz fasli")
# else:
#     print("Bunday oy raqami mavjud emas!")

# x =10
# def foo():
#     global x
#     x=20
#     foo()
#     print(x)


# def f(x):
#     if x <= 4: return x-1
#     else:return g(x-1) + f(x-2)
#
# def g(x):
#     if x <= 2: return 0
#     else:return f(x) - g(x-3)
# print(f(7) + g(4))


print(range(5))