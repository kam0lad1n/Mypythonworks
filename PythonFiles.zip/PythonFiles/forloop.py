# #1 masala
# for i in range(11):
#     print(i)
# #2-masala
# son = int(input("Enter a number: "))
# for i in range(son, 0, -1):
#     print(i)
# #3-masala
# for i in range(0, 21, 2):
#     print(i)
# #4-masala
# son = int(input("Enter a number: "))
# if son % 2 == 0:
#     for i in range(son, 500,2):
#         print(i+1)
# elif son % 2 == 1:
#     for i in range(son, 500,2):
#         print(i)
# #5-masala
# p = "Python"
# for i in p:
#     print(i)
# #6-masala
# for i in range(11):
#     print(i**2)
# #7-masala
# p = "salom dunyo"
# for i in p:
#     print(p)
# #8-masala
# sum = 0
# for i in range(101):
#     sum +=i
#     print(sum)
# #9-masala
# matn = str(input("Matn kiriting:"))
# for i in matn:
#     print(i)
# #10-masala
#....
# #11-masala
# import  random
# for i in range(10):
#     print(random.randint(0,999))
# #12-masala
# son1 = int(input("1-sonni kiriting: "))
# son2 = int(input("2-sonni kiriting: "))
# son3 = int(input("3-sonni kiriting: "))
# son4 = int(input("4-sonni kiriting: "))
# son5 = int(input("5-sonni kiriting: "))
# son6 = int(input("6-sonni kiriting: "))
# son7 = int(input("7-sonni kiriting: "))
# son8 = int(input("8-sonni kiriting: "))
# son9 = int(input("9-sonni kiriting: "))
# son10 = int(input("10-sonni kiriting: "))
# print("Musbat sonlar: ")
# if son1 >= 0:
#     print(son1)
# elif son2 >= 0:
#     print(son1)
# elif son3 >= 0:
#     print(son1)
# elif son4 >= 0:
#     print(son1)
# elif son5 >= 0:
#     print(son1)
# elif son6 >= 0:
#     print(son1)
# elif son7 >= 0:
#     print(son1)
# elif son8 >= 0:
#     print(son1)
# elif son9 >= 0:
#     print(son1)
# elif son10 >= 0:
#     print(son1)
# else:
#     print("Blar hammasi manfiy o'xshidi!")


# import random
# talaba = ["mrx","hamid","mirjalol","sardor"]
# jobs = ["mobiler", "frontchi","backendchi","dizayner"]
# for t in talaba:
#         print(t,random.choice(jobs))

# matn = str(input("Enter a text: "))
# unli = "aeuio"
# hisob = 0
# for i in matn:
#         if i in unli:
#             hisob +=1
# print("Matnda",hisob,"ta unli bor")














