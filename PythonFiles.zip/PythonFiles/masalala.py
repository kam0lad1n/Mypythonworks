chose = int(input("Qaysi masala kerak:"))
if chose == 1:
    x = int(input('X ga qiymat bering:'))
    print("Birinchi masala:")
    if x >= 0:
        print(x + 1)
    else:
        print(x)
elif chose == 2 :
    x = int(input('X ga qiymat bering:'))
    print("Ikkinchi masala:")
    if x > 0:
        print(x + 1)
    elif x == 0:
        on = 10
        print(on)
    else:
        print(x - 2)
elif chose == 3 :
    x = int(input('X ga qiymat bering:'))
    y = int(input('Y ga qiymat bering:'))
    z = int(input('Z ga qiymat bering:'))
    print("Uchinchi masala:")
    all = 0
    if x > 0:
        all += 1
    if y > 0:
        all += 1
    if z > 0:
        all += 1
    print("Musbat sonlar ",all,"ta")
elif chose == 4 :
    x = int(input('X ga qiymat bering:'))
    y = int(input('Y ga qiymat bering:'))
    z = int(input('Z ga qiymat bering:'))
    print("To'rtinchi masala:")
    if x > y:
        print(x, "soni katta")
    elif x == y:
        print("Bular teng")
    else:
        print(y, "soni katta")
elif chose == 5 :
    x = int(input('X ga qiymat bering:'))
    y = int(input('Y ga qiymat bering:'))
    z = int(input('Z ga qiymat bering:'))
    print("Beshinchi masala:")
    if x != y:
        print(x + 1, y + 1)
    elif x == y:
        print(x - x, y - y)
elif chose == 6 :
    x = int(input('X ga qiymat bering:'))
    y = int(input('Y ga qiymat bering:'))
    z = int(input('Z ga qiymat bering:'))
    print("Oltinchi masala:")
    if x < y and x < z:
        print("Eng kichiki", x)
    elif y < x and y < z:
        print("Eng kichiki", y)
    else:
        print("Eng kichiki", z)
elif chose == 7 :
    x = int(input('X ga qiymat bering:'))
    y = int(input('Y ga qiymat bering:'))
    z = int(input('Z ga qiymat bering:'))
    print("Yettinchi masala:")
    if x < y and y < z:
        print(x * x, y * y, z * z)
    else:
        print(-x, -y, -z)
elif chose == 8 :
    x = int(input('X ga qiymat bering:'))
    print("Sakkinchi masala:")
    if x < -2 or x > 2:
        print("f(x)=", x * 2)
    else:
        print("f(x)=", x * -3)
elif chose == 9 :
    x = int(input('X ga qiymat bering:'))
    print("To'qqizinchi masala:")
    if x <= 0:
        print("f(x)=", -x)
    elif x > 0 and x < 2:
        print(x ** 2)
    elif x >= 2:
        print("f(x)=", 4)
    else:
        print("error")
else:
    print("Bunday masala topilmadi!")