# 1masala
# son = 4
# if son%2==0 :
#     print("Juft")
# else:
#     print("Toq")
# 2masala
# son =0
# if son >0:
#     print("Musbat")
# elif son ==0:
#     print("0 ga teng")
# else:
#     print("Manfiy")
# 3masala
# n = int(input("Enter a number: "))
# b = 1
# while b<=n:
#     print(b)
#     b+=1
# 4masala
# n = int(input("Enter a number: "))
# b = 1
# while b<=n:
#     if b%2==0:
#        print(b)
#     b+=1
# 5masala
# list = [0,2,5,7]
# print(sum(list))
# 6masala
# soz = "Python"
# unli = "euiao"
# cout = 0
# for i in soz:
#     if i in unli:
#         cout += 1
# print(cout)
# 7masala
# soz = "Python"[::-1]
# print(soz)
# 8masala
# royxat =[7,5,8,1,2,4,9]
# royxat.sort()
# print(royxat[7])
# 9masala
# n = int(input("Enter a number: "))
# b = 1
# for i in range(1,n+1):
#     print(b**2)
#     b+=1
# 10masala
# royxat =[7,5,8,1,2,4,9][::-1]
# print(royxat)
# 11masala
# word = "kamoladdin"
# print(word)
# hafr = str(input("Qaysi harf: "))
# new = str(input("Yangi harf: "))
# print(word.replace(hafr,new))
# 13masala
# matn = "Salom dunyo!"
# print(matn.count(" "))
# 14masala
# royxat =[7,5,8,1,2,4,9]
# print(royxat)
# for i in royxat:
#     if i%2==1:
#         royxat.remove(i)
# print(royxat)
# 15masala
# matn = "Salom dunyo!"
# print(matn.upper())
# 16masala
# n = int(input("Enter a number: "))
# b=1
# for i in range(1,n+1):
#     b=b*i
#     print(b)
# 17masala
# royxat =[7,5,8,1,2,4,9]
# print(royxat)
# son = int(input("Qaysi elem:"))
# for i in royxat:
#     item=royxat.index(son)
#     kop = int(input("Qanchaga:"))
#     print(kop*item)
# 18masala
# matn = ["Salom","dunyo"]
# matn.reverse()
# print(matn)
# 20masala
# royxat =[7,5,8,1,2,4,9]
# royxat.sort()
# print(royxat)









