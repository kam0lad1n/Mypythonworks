# x = int(input("Enter a number: "))
# y = int(input("Enter a number: "))
# z = int(input("Enter a number: "))
#
# if x > y and  y > z :
#     print(z)
# elif x < y and x < z :
#     print(x)
# elif y < x and y < z :
#     print(y)
# else:
#     print("Error")

# a = int(input(" a number: "))
# b = int(input(" b number: "))
#
# if a!=b:
#     print("A son",a+1,"\nB son", b+1)
# else:
#     print("A son",a-a,"\nB son", b-b)
















a = int(input(" a number: "))



if  a <= 0 :
    y = -a
    print(y)
# elif:
#     print("f(",x , ")")
#
# if 0 < x and x < 2:
#     print(x**2)
else:
    print("emas")

